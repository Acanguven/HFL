﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsFreeLeveler
{
    public static class User
    {
        public static string username { get; set; }
        public static string password { get; set; }
        public static bool multiSmurf { get; set; }
        public static string hwid { get; set; }
        public static string trialRemains { get; set; }
        public static bool trial { get; set; }
    }
}
